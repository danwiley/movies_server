import time
from flask import Flask, render_template, request, jsonify
import requests
import os
import subprocess
from file_to_magnet import torrent_to_magnet
import shutil
import re
import json
import threading
from datetime import datetime, timedelta
from subtitles import download_sub
app = Flask(__name__)
DOWNLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'downloads')

if not os.path.exists(DOWNLOAD_FOLDER):
    os.makedirs(DOWNLOAD_FOLDER)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/movie.html')
def movie():
    return render_template('movie.html')



@app.route('/download', methods=['POST'])
def download():
    torrent_url = request.form['url']
    response = requests.get(torrent_url, stream=True)

    if response.status_code == 200:
        if 'content-disposition' in response.headers:
            file_name = response.headers['content-disposition'].split('filename=')[-1].strip('\"')
        else:
            file_name = torrent_url.split('/')[-1]
            if not file_name.endswith('.torrent'):
                file_name += '.torrent'

        video_path = os.path.join(DOWNLOAD_FOLDER, file_name)
        with open(video_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        result = subprocess.run(['node', 'torrentFileNames.mjs', video_path], capture_output=True, text=True)
        video_name = result.stdout.strip()
        file_magnet = torrent_to_magnet(video_path)
        #os.remove(video_path)



        return jsonify({"status": "success", "file_name": video_name, "file_magnet": file_magnet}), 200
    else:
        return jsonify({"status": "error", "message": "Failed to download file"}), 500


@app.route('/popular_movies')
def popular_movies():
    try:
        with open("movies_json.txt", "r") as f:
            content = f.read()
    except:
        get_popular_movies()
        with open("movies_json.txt", "r") as f:
            content = f.read()


    return (content)



@app.route('/get_popular_movies')
def get_popular_movies():
    url = "https://www.imdb.com/chart/moviemeter/"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }

    response = requests.get(url, headers=headers)

    pattern = r'https://www.imdb.com/title/(tt\d{7,8})/'
    matches = re.findall(pattern, response.text)
    movies_json = []
    for i, x in enumerate(matches):
        temp_movie = requests.get(f"https://yts.mx/api/v2/movie_details.json?imdb_id={x}")
        temp_movie = json.loads(temp_movie.text)
        movie_id = temp_movie.get("data", {}).get("movie", {}).get("id")
        if movie_id != 0:
            movies_json.append(temp_movie.get("data", {}).get("movie", {}))
    with open('movies_json.txt', 'w', encoding='utf-8') as f:
        json.dump(movies_json, f, ensure_ascii=False, indent=4)

    return "done"


@app.route('/stream/<movie>')
def stream_movie(movie):
    base_path = r'static\subtitles'

    if not os.path.exists(f'{base_path}\{movie}0.vtt'):
        download_sub(movie)
        #pass

    subtitle_files = []

    for i in range(4):
        subtitle_path = os.path.join(base_path, f'{movie}{i}.vtt')
        if os.path.exists(subtitle_path):
            subtitle_files.append(f'{movie}{i}.vtt')

    return render_template('stream.html', movie=movie, subtitle_files=subtitle_files)



def delete_contents(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            os.remove(os.path.join(root, file))
        for dir in dirs:
            shutil.rmtree(os.path.join(root, dir))





def background_task():
    now = datetime.now()
    midnight = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    time_to_sleep =  (midnight - now).total_seconds()

    requests.get("http://10.100.102.19:5000/get_popular_movies")

    print(f"successfully updated popular movies {midnight}")

    time.sleep(time_to_sleep)

    time_to_sleep = 86400
    while True:
        requests.get("http://10.100.102.19:5000/get_popular_movies")
        print(f"successfully updated popular movies {midnight}")

        time.sleep(time_to_sleep)




if __name__ == '__main__':
    #delete_contents(r'D:\movies')
    #delete_contents(r'C:\tmp\torrent-stream')
    #delete_contents(r'static\subtitles')
    #delete_contents(r'downloads')
    if os.environ.get('WERKZEUG_RUN_MAIN') == 'true':
        # Start the background task in a separate thread
        background_thread = threading.Thread(target=background_task)
        background_thread.daemon = True  # Ensure it exits when the main thread does
        background_thread.start()

    app.run(debug=True, host='0.0.0.0')





