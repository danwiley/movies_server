from flask import Flask, render_template, request, jsonify
import requests
import os
from file_to_magnet import torrent_to_magnet
import shutil
import re
import json
import threading
from datetime import datetime, timedelta
from subtitles import download_sub
import time
app = Flask(__name__)
DOWNLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'downloads')

if not os.path.exists(DOWNLOAD_FOLDER):
    os.makedirs(DOWNLOAD_FOLDER)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/movie.html')
def movie():
    return render_template('movie.html')


@app.route('/download', methods=['POST'])
def download():

    torrent_url = request.form['url']

    file_name = torrent_url.split("download/")[1]


    video_path = os.path.join(DOWNLOAD_FOLDER, file_name)

    if not os.path.exists(video_path):
        response = requests.get(torrent_url)

        with open(video_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

    file_magnet = torrent_to_magnet(video_path)
    return jsonify({"status": "success", "file_magnet": file_magnet}), 200



@app.route('/popular_movies')
def popular_movies():
    try:
        with open("movies_json.txt", "r") as f:
            content = f.read()
    except:
        get_popular_movies()
        with open("movies_json.txt", "r") as f:
            content = f.read()

    return (content)



def get_popular_movies():
    url = "https://www.imdb.com/chart/moviemeter/"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }

    response = requests.get(url, headers=headers)
    pattern = r'https://www.imdb.com/title/(tt\d{7,8})/'
    matches = re.findall(pattern, response.text)
    movies_json = []
    for i, x in enumerate(matches):
        temp_movie = requests.get(f"https://yts.mx/api/v2/movie_details.json?imdb_id={x}")
        temp_movie = json.loads(temp_movie.text)
        movie_id = temp_movie.get("data", {}).get("movie", {}).get("id")
        if movie_id != 0:
            movies_json.append(temp_movie.get("data", {}).get("movie", {}))
    with open('movies_json.txt', 'w', encoding='utf-8') as f:
        json.dump(movies_json, f, ensure_ascii=False, indent=4)



working_accounts = 6
subtitle_files = []

@app.route('/subtitles/<movie>')
def download_subtitles(movie):
    global working_accounts
    global subtitle_files
    base_path = r'static\subtitles'

    if (not os.path.exists(f'{base_path}\{movie}0.vtt')) and (working_accounts > 0):
        working_accounts = download_sub(movie, working_accounts)
        # print(f"working accounts: {working_accounts}")

    subtitle_files = []
    for i in range(5):
        subtitle_path = os.path.join(base_path, f'{movie}{i}.vtt')
        if os.path.exists(subtitle_path):
            subtitle_files.append(f'{movie}{i}.vtt')
        else:
            break

    return "done"



@app.route('/stream')
def stream_movie():
    global subtitle_files
    return render_template('stream.html', subtitle_files=subtitle_files)

@app.route('/shutdown', methods=['POST'])
def shutdown():
    #os.system("sudo shutdown now")
    return jsonify({"status": "Shutdown message received"}), 200

def delete_contents(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            os.remove(os.path.join(root, file))
        for dir in dirs:
            shutil.rmtree(os.path.join(root, dir))




def time_to_midnight():
    now = datetime.now()
    midnight = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    return  (midnight - now).total_seconds()

def background_task():
    global working_accounts
    get_popular_movies()
    print(f"successfully updated popular movies")
    time.sleep(time_to_midnight())

    while True:
        get_popular_movies()
        print(f"successfully updated popular movies")
        working_accounts = 6
        time.sleep(time_to_midnight())



if __name__ == '__main__':
    delete_contents(r'D:\movies')
    delete_contents(r'C:\tmp\torrent-stream')
    delete_contents(r'static\subtitles')
    delete_contents(r'downloads')



    if os.environ.get('WERKZEUG_RUN_MAIN') == 'true':
        # Start the background task in a separate thread
        background_thread = threading.Thread(target=background_task)
        background_thread.daemon = True  # Ensure it exits when the main thread does
        background_thread.start()


    app.run(debug=True, host='0.0.0.0')





