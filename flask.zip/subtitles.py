import time
from opensubtitlescom import OpenSubtitles
import json
from difflib import SequenceMatcher


def download_sub(query, working_accounts):

    def format_timedelta(td):
        total_seconds = int(td.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        milliseconds = td.microseconds // 1000
        return f"{hours:02}:{minutes:02}:{seconds:02}.{milliseconds:03}"

    with open("accounts.json", 'r') as file:
        data = json.load(file)

    subtitles_saved = False  # Flag to indicate if subtitles are saved

    for i in range(6-working_accounts, 6):
        if subtitles_saved:  # Break the loop if subtitles are saved
            break

        # Initialize the OpenSubtitles client
        subtitles = OpenSubtitles(data['accounts'][i]['app'], data['accounts'][i]['key'])

        # Log in (retrieve auth token)
        subtitles.login(data['accounts'][i]['username'], data['accounts'][i]['password'])

        # Search for subtitles
        response = subtitles.search(query=query, languages="he", order_by="downloads")

        subtitles_list = []
        subtitles_score = []
        if response.data:
            for loop in range(5):
                try:
                    # Define the file path to save the subtitles
                    # Get first response subtitles
                    srt = subtitles.download_and_parse(response.data[loop])
                    subtitle_name = response.data[loop].file_name if hasattr(response.data[loop], 'file_name') else str(response.data[loop])
                    matcher = SequenceMatcher(None, query, subtitle_name)
                    similarity_ratio = matcher.ratio()

                    # Convert to WebVTT format
                    vtt_content = "WEBVTT\n\n"
                    for subtitle in srt:
                        start = format_timedelta(subtitle.start)
                        end = format_timedelta(subtitle.end)
                        content = subtitle.content
                        vtt_content += f"{subtitle.index}\n{start} --> {end}\n{content}\n\n"

                    subtitles_list.append(vtt_content)
                    subtitles_score.append(similarity_ratio)

                except Exception as e:
                    #print(e)
                    break

                subtitles_saved = True  # Set the flag to True
                corrent_account = 6 - i
        else:
            subtitles_saved = True  # Set the flag to True
        time.sleep(0.5)

    sorted_data = [x for _, x in sorted(zip(subtitles_score, subtitles_list), reverse=True)]
    for index, item in enumerate(sorted_data):
        vtt_file_path = f"static/subtitles/{query}{index}.vtt"

        # Write the subtitles to a VTT file
        with open(vtt_file_path, "w", encoding="utf-8") as file:
            file.write(item)

    try:
        return corrent_account
    except:
        return working_accounts

