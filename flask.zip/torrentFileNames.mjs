import fs from 'fs';
import WebTorrent from 'webtorrent';

async function getTorrentFileNames(torrentFilePath) {
    const client = new WebTorrent();

    // Read the torrent file
    const torrentFile = fs.readFileSync(torrentFilePath);

    client.add(torrentFile, { announce: false }, torrent => {
        torrent.files.forEach(file => {
            if (file.name.endsWith('.mp4') ||file.name.endsWith('.mkv')  ) {
                console.log(file.name); // Output the file name
                const video_name = file.name
            }
        });
        client.destroy();
    });

    client.on('error', err => {
        console.error('Error:', err.message);
        client.destroy();
    });
}

// Get the torrent file path from command line arguments
const torrentFilePath = process.argv[2];
if (!torrentFilePath) {
    console.error('Please provide a torrent file path');
    process.exit(1);
}

getTorrentFileNames(torrentFilePath);
