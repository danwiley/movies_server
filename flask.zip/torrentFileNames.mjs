import fs from 'fs';
import WebTorrent from 'webtorrent';

async function getTorrentFileNames(torrentFilePath) {
    const client = new WebTorrent();
    const torrentFile = fs.readFileSync(torrentFilePath);
    client.add(torrentFile, { announce: false }, torrent => {
        torrent.files.forEach(file => {
            if (file.name.endsWith('.mp4') ||file.name.endsWith('.mkv')  ) {
                console.log(file.name);
            }
        });
        client.destroy();
    });
}

const torrentFilePath = process.argv[2];
getTorrentFileNames(torrentFilePath);
